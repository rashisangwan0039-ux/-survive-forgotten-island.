KALGAD — FESTIVAL SQUARE 3D ENVIRONMENT PASS
Chapter 1.

This build is the next step after the interaction prototype:
- Real Three.js 3D fort courtyard
- Citadel gate, walls, towers, stalls, fountain, banners and lantern lighting
- Third-person player camera
- NPCs and first interaction chain
- Festival Guard -> Musician -> Notice -> Merchant -> Fountain -> Black Seal -> Guard
- Custom display-name field
- Desktop + basic touch controls

The page loads Three.js from jsDelivr, so an internet connection is required.
This is an environment/gameplay pass, not the final AAA character asset build.
