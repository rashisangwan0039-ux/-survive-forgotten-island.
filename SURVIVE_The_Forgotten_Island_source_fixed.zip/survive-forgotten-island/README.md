# SURVIVE: The Forgotten Island

A playable multiplayer survival-game MVP built with Babylon.js and Colyseus.

## Requirements
- Node.js 20+
- npm 10+

## Run locally
```bash
npm install
npm run dev
```
Open `http://localhost:5173` in two browser windows/devices on the same network. The server listens on port `2567`.

## Controls
- Desktop: click the game to lock the mouse; WASD to move; mouse to look; Shift to sprint; E to collect; Esc to release the mouse.
- Touch: left directional pad to move, drag the look pad to look, COLLECT to pick up nearby items, SPRINT to run.
- One player chooses **Create Private Island** and shares the displayed room ID. Others enter that code and choose **Join**.
- Collect 3 scrap, 2 wire and 1 battery, then use **Craft Radio Part** to complete the rescue objective.

## Deployment

A starter `render.yaml` is included for a Render web service and static site. Before deploying, change the `VITE_SERVER_URL` value to the actual backend hostname assigned by your hosting provider, then trigger a fresh frontend build. The server needs a persistent WebSocket-capable service; a static-only host cannot run the Colyseus backend.

Deploy the `server` workspace as a persistent Node service with WebSocket support and expose port `2567` (or set `PORT`). Deploy `client` as a static Vite site and set `VITE_SERVER_URL` to the public `wss://` URL of the Colyseus server. Rebuild the client after setting the environment variable.

The room ID is the private invite code. Colyseus limits each room to 10 clients. The server validates movement vectors, island bounds, action rate limits, collection distance, and crafting inventory.

## Current MVP scope
Procedural island environment, first-person camera, multiplayer player state, private room IDs, survival vitals, resource pickups, inventory, radio-repair win condition, day/night clock, keyboard and touch controls. This is an early MVP: production-grade anti-cheat, persistent accounts, advanced character animation, audio, and high-fidelity terrain/vegetation are not included.
