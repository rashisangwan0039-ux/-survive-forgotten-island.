import { Room, Client, Server as ColyseusServer } from "@colyseus/core";
import { Schema, MapSchema, type } from "@colyseus/schema";
import { createServer } from "http";
import express from "express";
import cors from "cors";
import { WebSocketTransport } from "@colyseus/ws-transport";

class Player extends Schema {
  @type("string") name = "Survivor";
  @type("number") x = 0;
  @type("number") y = 1.3;
  @type("number") z = 12;
  @type("number") yaw = 0;
  @type("number") health = 100;
  @type("number") hunger = 100;
  @type("number") thirst = 100;
  @type("number") stamina = 100;
}
class Resource extends Schema {
  @type("string") kind = "scrap";
  @type("number") x = 0;
  @type("number") z = 0;
  @type("boolean") collected = false;
}
class IslandState extends Schema {
  @type({ map: Player }) players = new MapSchema<Player>();
  @type({ map: Resource }) resources = new MapSchema<Resource>();
  @type("number") dayTime = 400;
  @type("boolean") missionComplete = false;
}
type Bag = Record<string, number>;
const kinds = ["scrap","scrap","scrap","wire","wire","battery","fruit","fruit","water","water","scrap","wire","fruit","water"];
function randomPos(){const a=Math.random()*Math.PI*2,r=5+Math.random()*21;return {x:Math.cos(a)*r,z:Math.sin(a)*r};}
export class SurvivalRoom extends Room<IslandState> {
  maxClients = 10;
  private bags = new Map<string,Bag>();
  private actionTimes = new Map<string,number>();
  private moveTimes = new Map<string,number>();
  onCreate(){
    this.setState(new IslandState());
    this.setMetadata({mode:"private-survival",maxPlayers:10});
    kinds.forEach((kind,i)=>{const pos=randomPos();const r=new Resource();r.kind=kind;r.x=pos.x;r.z=pos.z;this.state.resources.set(`res-${i}`,r);});
    this.onMessage("move",(client,msg)=>this.handleMove(client,msg));
    this.onMessage("action",(client,msg)=>this.handleAction(client,msg));
    this.clock.setInterval(()=>this.simulate(),1000);
    this.onMessage("ping",(client)=>client.send("pong",{at:Date.now()}));
  }
  onJoin(client:Client,options:any){
    const p=new Player();p.name=typeof options.name==="string"?options.name.replace(/[^\w -]/g,"").slice(0,16)||"Survivor":"Survivor";
    const spawn=randomPos();p.x=spawn.x;p.z=spawn.z;
    this.state.players.set(client.sessionId,p);this.bags.set(client.sessionId,{});
    client.send("roomInfo",{code:this.roomId});
    this.sendBag(client);
    this.broadcast("notice",{text:`${p.name} joined the island.`}, {except:client});
  }
  async onLeave(client:Client, consented:boolean){
    const name=this.state.players.get(client.sessionId)?.name??"A survivor";
    if(!consented){
      try { await this.allowReconnection(client,20); this.broadcast("notice",{text:`${name} reconnected.`}); return; }
      catch { /* reconnection window expired; remove the survivor below */ }
    }
    this.state.players.delete(client.sessionId);this.bags.delete(client.sessionId);this.actionTimes.delete(client.sessionId);this.moveTimes.delete(client.sessionId);
    this.broadcast("notice",{text:`${name} left the island.`});
  }
  private handleMove(client:Client,msg:any){
    const p=this.state.players.get(client.sessionId);if(!p||!msg||typeof msg!=="object")return;
    const now=Date.now(),last=this.moveTimes.get(client.sessionId)||0;if(now-last<35)return;this.moveTimes.set(client.sessionId,now);
    const f=Number(msg.forward),s=Number(msg.side),yaw=Number(msg.yaw);
    if(!Number.isFinite(f)||!Number.isFinite(s)||!Number.isFinite(yaw)||Math.abs(f)>1||Math.abs(s)>1||Math.abs(yaw)>Math.PI*100)return;
    p.yaw=yaw;const len=Math.hypot(f,s)||1,speed=msg.sprint===true&&p.stamina>1?5.8:3.25;
    const dt=Math.min(.12,(now-last)/1000||.045),fx=Math.sin(yaw),fz=Math.cos(yaw);
    const dx=(fx*f+Math.cos(yaw)*s)/len*speed*dt;
    const dz=(fz*f-Math.sin(yaw)*s)/len*speed*dt;
    const nx=p.x+dx,nz=p.z+dz;
    if(Math.hypot(nx,nz)<=29){p.x=nx;p.z=nz;}
    if(msg.sprint===true&&(f!==0||s!==0))p.stamina=Math.max(0,p.stamina-1.5);else p.stamina=Math.min(100,p.stamina+.8);
  }
  private handleAction(client:Client,msg:any){
    const p=this.state.players.get(client.sessionId);if(!p||!msg||typeof msg.type!=="string")return;
    const now=Date.now(),last=this.actionTimes.get(client.sessionId)||0;if(now-last<250)return;this.actionTimes.set(client.sessionId,now);
    const bag=this.bags.get(client.sessionId)!;
    if(msg.type==="collect"){
      let nearest:Resource|undefined,nearestId="",dist=3.2;
      this.state.resources.forEach((r,id)=>{if(r.collected)return;const d=Math.hypot(r.x-p.x,r.z-p.z);if(d<dist){dist=d;nearest=r;nearestId=id;}});
      if(!nearest){client.send("notice",{text:"Move closer to a glowing resource."});return;}
      nearest.collected=true;bag[nearest.kind]=(bag[nearest.kind]||0)+1;
      if(nearest.kind==="fruit")p.hunger=Math.min(100,p.hunger+18);
      if(nearest.kind==="water")p.thirst=Math.min(100,p.thirst+24);
      this.sendBag(client);client.send("notice",{text:`Collected ${nearest.kind}.`});
    }else if(msg.type==="craft"){
      if((bag.scrap||0)>=3&&(bag.wire||0)>=2&&(bag.battery||0)>=1){
        bag.scrap-=3;bag.wire-=2;bag.battery-=1;this.state.missionComplete=true;
        this.broadcast("notice",{text:`${p.name} repaired the radio! Rescue signal transmitted.`});
        this.sendBag(client);
      }else client.send("notice",{text:"Need 3 scrap, 2 wire and 1 battery to repair the radio."});
    }
  }
  private sendBag(client:Client){client.send("inventory",{items:this.bags.get(client.sessionId)||{}});}
  private simulate(){
    this.state.dayTime=(this.state.dayTime+1)%2400;
    this.state.players.forEach(p=>{
      p.hunger=Math.max(0,p.hunger-.035);p.thirst=Math.max(0,p.thirst-.055);
      if(p.hunger===0||p.thirst===0)p.health=Math.max(0,p.health-.12);
      else if(p.health<100)p.health=Math.min(100,p.health+.015);
    });
  }
  onDispose(){this.bags.clear();}
}
const app=express();app.use(cors());app.get("/health",(_req,res)=>res.json({ok:true,game:"SURVIVE: The Forgotten Island",transport:"Colyseus WebSocket"}));
const server=createServer(app);
const port=Number(process.env.PORT||2567);
const game=new ColyseusServer({transport:new WebSocketTransport({server})});
game.define("survival",SurvivalRoom);
game.listen(port);
console.log(`SURVIVE multiplayer server listening on ${port}`);
